export MBK_CATA_LIB=.:../libraries_and_tools/sg13g2/:../libraries_and_tools/sg13g2/models:../libraries_and_tools/sg13g2/nsx2/
export RDS_TECHNO_NAME=../libraries_and_tools/sg13g2/nsx2/sg13g2.rds

crlenv.py  -- bash -c 's2r -r counter_r counter_r'
