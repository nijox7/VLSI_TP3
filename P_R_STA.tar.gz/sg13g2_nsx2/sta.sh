Temperature=25.0
VddName='vdd'
VssName='vss'
ClockSignal='ck'
Target='counter_ext'
vddvolt='1.8'



export MBK_CATA_LIB=.:../libraries_and_tools/sg13g2/:../libraries_and_tools/sg13g2/models:../libraries_and_tools/sg13g2/nsx2/
export RDS_TECHNO_NAME=../libraries_and_tools/sg13g2/nsx2/sg13g2.rds
export MBK_OUT_LO=spi
export MBK_SPI_MODEL=../libraries_and_tools/sg13g2/nsx2/spimodel.cfg
#extraction in transistor netlist
crlenv.py  -- bash -c 'cougar -t -v counter_r counter_ext'





../libraries_and_tools/sg13g2/timing.tcl -Target $Target -VddVoltage $vddvolt -ClockSignal  $ClockSignal -VddName $VddName   -VssName $VssName   -Temperature $Temperature
