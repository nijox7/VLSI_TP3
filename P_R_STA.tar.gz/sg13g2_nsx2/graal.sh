
crlenv.py  -- bash -c ' export MBK_CATA_LIB=../libraries_and_tools/symbolic/cells/nsxlib2/ ;       graal'
