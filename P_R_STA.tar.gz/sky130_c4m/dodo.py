
from coriolis.designflow.technos import setupSky130_c4m

setupSky130_c4m( '../../../../../..', '../libraries_and_tools/sky130/pdkmaster/C4M.Sky130' )

DOIT_CONFIG = { 'verbosity' : 2 }

from coriolis.designflow.task     import Tasks
from coriolis.designflow.pnr      import PnR
from coriolis.designflow.yosys    import Yosys
from coriolis.designflow.blif2vst import Blif2Vst
from coriolis.designflow.alias    import Alias
from coriolis.designflow.clean    import Clean
PnR.textMode  = True

from doDesign  import scriptMain
topName = 'scalar_product'
ruleYosys = Yosys   .mkRule( 'yosys', f'{topName}.v' )
ruleB2V   = Blif2Vst.mkRule( 'b2v'  , [f'{topName}.vst' ]
                                    , [ruleYosys]
                                    , flags=0 )
rulePnR   = PnR     .mkRule( 'pnr'  , [ f'{topName}_r.gds'
                                      , f'{topName}_r.spi'
                                      , f'{topName}_r.vst' ]
                                    , [ruleYosys]
                                    , scriptMain )
ruleCgt   = PnR     .mkRule( 'cgt' )
ruleGds   = Alias   .mkRule( 'gds', [rulePnR] )
ruleClean = Clean   .mkRule()
