
export MBK_CATA_LIB=.:../libraries_and_tools/sky130:../libraries_and_tools/sky130/models:../libraries_and_tools/sky130/nsx2/
export RDS_TECHNO_NAME=../libraries_and_tools/sky130/nsx2/sky130_nsx3.rds
crlenv.py  -- bash -c 's2r -r counter_r counter_r'
