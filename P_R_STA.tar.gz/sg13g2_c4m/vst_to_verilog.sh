crlenv.py  -- bash -c "vasy -v -I vst counter_r"
