Temperature=25.0
VddName='vdd'
VssName='vss'
ClockSignal='ck'
Target='counter_r'
vddvolt='1.8'
export MBK_CATA_LIB=./:../libraries_and_tools/sg13g2/:../libraries_and_tools/sg13g2/models/:../libraries_and_tools/sg13g2/c4m/
../libraries_and_tools/sg13g2/timing.tcl -Target $Target -VddVoltage $vddvolt -ClockSignal  $ClockSignal -VddName $VddName   -VssName $VssName   -Temperature $Temperature
