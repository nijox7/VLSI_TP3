import sys
import pathlib
from coriolis.designflow.task    import ShellEnv, Tasks
checkToolkit=pathlib.Path('../libraries_and_tools/symbolic')
DOIT_CONFIG = { 'verbosity' : 2 }
from coriolis                               import CRL
from coriolis.designflow.task               import ShellEnv, Tasks
from coriolis.designflow.vasy               import Vasy
from coriolis.designflow.iverilog           import Iverilog
from coriolis.designflow.gtkwave            import GtkWave
from coriolis.designflow.yosys              import Yosys
from coriolis.designflow.blif2vst           import Blif2Vst
from coriolis.designflow.klayout            import Klayout
from coriolis.designflow.pnr                import PnR
from coriolis.designflow.lvx                import Lvx
from coriolis.designflow.cougar             import Cougar
from coriolis.designflow.druc               import Druc
from coriolis.designflow.tasyagle           import TasYagle, XTas
from coriolis.designflow.alias              import Alias
from coriolis.designflow.clean              import Clean
from coriolis.designflow.blif2vst           import Blif2Vst
from coriolis.designflow.klayout            import DRC
from coriolis.designflow.alias              import Alias
from coriolis.designflow.clean              import Clean

pdkDir          = checkToolkit / 'dks' / 'gf180mcu_nsx2' / 'libs.tech'
coriolisTechDir = pdkDir / 'coriolis' / 'gf180mcu_nsx2'
sys.path.append( coriolisTechDir.as_posix() )
import Gf180mcuSetup 
Gf180mcuSetup.setupGf180mcu_nsx2( checkToolkit )

kdrcRules = pdkDir / 'klayout' / 'drc' /  'gf180mcu.drc'

pdkCommonDir          = checkToolkit / 'dks' / 'common'  / 'coriolis'
pdkCommonTechDir      = checkToolkit / 'dks' / 'common'  / 'libs.tech' / 'globalfoundries-pdk-libs-gf180mcu_fd_pr' / 'models' / 'ngspice'
sys.path.append( pdkCommonDir.as_posix() )
from s2r import S2R
import pnrcheck
from sta                          import STA
pnrcheck.textMode  = True
import doDesign

topName = 'scalar_product'
S2R.flags = S2R.PinLayer | S2R.DeleteSubConnectors | S2R.Verbose|S2R.NoReplaceBlackboxes 

DRC.setDrcRules( kdrcRules )

ruleYosys = Yosys   .mkRule( 'yosys', topName+'.v' )
ruleB2V   = Blif2Vst.mkRule( 'b2v'  , topName+'.vst', [ruleYosys], flags=0 )

rulePnR = PnR.mkRule( 'pnr', [topName+'_r.ap'
                            , topName+'_r.vst'
                            , topName+'_r.spi' ]
                            , [ruleB2V]
                            , doDesign.scriptMain
                            , topName=topName )

ruleVasy  = Vasy.mkRule( 'vasy', topName+'_r.v'
                               , rulePnR.file_target(1)
                               , Vasy.Overwrite|Vasy.RemovePowerSupplies )

ruleIverilog = Iverilog.mkRule( 'iverilog', [ ruleVasy, 'tb_scalar_product.v' ] )

ruleCougar = Cougar.mkRule( 'cougar', topName+'_r_ext.vst', [rulePnR], flags=Cougar.Verbose )

ruleLvx    = Lvx.mkRule( 'lvx', [ rulePnR.file_target(1)
                                , ruleCougar.file_target(0) ]
                                , flags=Lvx.Flatten )

ruleDruc   = Druc.mkRule( 'druc'  , [rulePnR], flags=0 )



ruleCougarSpi = Cougar.mkRule( 'cougarSpi', topName+'_ext.spi'
							              , [rulePnR]
							              , Cougar.Transistor | Cougar.Verbose )


STA.VddSupply = 3.3
STA.ClockName = 'clk'
STA.SpiceType = 'hspice'

STA.SpiceTrModel = 'typical.lib design.ngspice sm141064.ngspice'
STA.MBK_CATA_LIB = '.:'+str( coriolisTechDir )+':'+str( pdkCommonTechDir )
print(STA.MBK_CATA_LIB )
shellEnv = ShellEnv()
shellEnv[ 'MBK_SPI_MODEL' ] =  str( coriolisTechDir / 'spimodel.cfg' )
shellEnv.export()
STA.flags = STA.Transistor
staTargets = [ topName+'_ext.cpath.rep'
                 , topName+'_ext.cns'
                 , topName+'_ext.cnv'
                 , topName+'_ext.dtx'
                 , topName+'_ext.rcx'
                 , topName+'_ext.rep'
                 , topName+'_ext.slack.rep'
                 , topName+'_ext.stat'
                 , topName+'_ext.stm'
                 , topName+'_ext.sto'
                 , topName+'_ext.str' ] 
ruleSTA     = STA.mkRule( 'sta'    , staTargets, [ruleCougarSpi] )
ruleXTas    = XTas.mkRule( 'xtas'   , ruleSTA.file_target(0) )
ruleCgt     = PnR.mkRule( 'cgt' )
ruleClean   = Clean  .mkRule( [ 'lefRWarning.log', 'cgt.log' ] )

