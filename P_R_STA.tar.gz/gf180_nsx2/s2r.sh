export MBK_CATA_LIB=.:../libraries_and_tools/gf180/:../libraries_and_tools/gf180/models:../libraries_and_tools/gf180/nsx2/
export RDS_TECHNO_NAME=../libraries_and_tools/gf180/nsx2/gf180mcu.rds
crlenv.py  -- bash -c 's2r -r counter_r counter_r'
