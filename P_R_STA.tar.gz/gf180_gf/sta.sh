Temperature=25.0
VddName='VDD'
VssName='VSS'
ClockSignal='ck'
Target='counter_r'
vddvolt='5.0'
export MBK_CATA_LIB=./:../libraries_and_tools/gf180/:../libraries_and_tools/gf180/models/:../libraries_and_tools/gf180/native/
crlenv.py -- bash -c "vasy -v -I vst $Target"
python ../libraries_and_tools/gf180/verilog_to_spi.py  -l ../libraries_and_tools/gf180/native/stdcell.spi  -m counter_r
../libraries_and_tools/gf180/native/timing.tcl -Target $Target -VddVoltage $vddvolt -ClockSignal  $ClockSignal -VddName $VddName   -VssName $VssName   -Temperature $Temperature
