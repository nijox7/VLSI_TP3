crlenv.py  -- bash -c "vasy -v -I vst counter_r"
python ../libraries_and_tools/gf180/verilog_to_spi.py  -l ../libraries_and_tools/gf180/native/stdcell.spi  -m counter_r
mv renamed_verilog.v  counter_r.v
