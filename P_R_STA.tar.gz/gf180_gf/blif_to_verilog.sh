yosys -p 'read_blif counter.blif ; write_verilog counter_synth.v'

