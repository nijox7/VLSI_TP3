import re
import sys
from pathlib import Path
import argparse

def get_args():
  ap = argparse.ArgumentParser(
          description     = 'converts verilog to spi',
          formatter_class = argparse.ArgumentDefaultsHelpFormatter)
  ap.add_argument('-m', '--module',      type=str, default='uart_rx'  ,help='specify the module name, it should have the same name than the file')

  ap.add_argument('-e', '--extracted', action='store_true',
                    help='enable extracted mode (requires --spef)')

  ap.add_argument('-s', '--spef', type=str,
                    help='path to spef file (required if -e is used)')
  ap.add_argument('-l', '--lib',      type=str, default='stdcell.spi'  ,help='specify the spi library')

  args = ap.parse_args()
  if args.extracted and not args.spef:
        ap.error("the argument -e/--extracted requires --spef <file>")

  return args


class Cell:
    def __init__(self, model_name, pins):
        self.model_name = model_name
        self.pins = pins


class CellInstance:
    def __init__(self, cell_type, instance_name, connections):
        self.cell_type = cell_type  # objet de type Cell
        self.instance_name = instance_name
        self.connections = connections  # dictionnaire {pin: signal}
    def extract_pins(self):
        pin_dict={}
        for item in self.connections:
            parts = item.split('.')  
            for p in parts:
                if '(' in p and ')' in p:
                    pin = p.split('(')[0].strip()
                    sig = p.split('(')[1].split(')')[0].strip()
                    pin_dict[pin] = sig
        power_pins_defaults = {
            "VDD": "VDD",
            "VSS": "VSS",
            "VNW": "VNW",
            "VPW": "VPW"
        }
        for power_pin, default_signal in power_pins_defaults.items():
                pin_dict[power_pin] = default_signal
        return pin_dict
            

def generate_cell_class(std_file):
    cells = []
    with open(std_file, 'r') as f:
        for line in f:
            stripped = line.strip()
            if stripped.startswith('.SUBCKT'):
                instantiation = stripped.split('.SUBCKT')[1]
                class_name = instantiation.split()[0]
                pins = instantiation.split()[1:]
                cell = Cell(model_name=class_name, pins=pins)
                cells.append(cell)
    return cells



def extract_instances(verilog_file, valid_cell_types):
    instances = []
    current = []
    in_instance_definition = False
    with open(verilog_file, 'r') as f:
        for raw_line in f:
          raw_line = raw_line.replace(");", ");\n")
          for line in raw_line.split("\n"):
            stripped = line.strip()
            if not stripped:
                continue
            parts = stripped.split()
            if not in_instance_definition and parts[0] in valid_cell_types:
                cell_name = parts[0]
                instance_name = parts[1].split("(")[0]
                if ");" in stripped:
                    inside_paren = line.split("(", 1)[1].rsplit(")", 1)[0].strip()
                    current = [inside_paren] if inside_paren else []
                    instances.append( CellInstance(cell_type=cell_name, instance_name =instance_name , connections=current) )
                else:
                    if "(" in line:
                        after_paren = line.split("(", 1)[1].strip()
                        current = [after_paren] if after_paren else []
                    else:
                        current = []
                    in_instance_definition = True
            elif in_instance_definition:
                current.append(stripped)
                if stripped.endswith(");"):
                    instances.append( CellInstance(cell_type=cell_name, instance_name =instance_name , connections=current) )
                    in_instance_definition = False
                    current = []

    return instances


def get_top_module_info(verilog_file):
    module_name = None
    port_lines = []
    in_module_header = False

    with open(verilog_file, 'r') as f:
        for line in f:
            stripped = line.strip()
            if not in_module_header and stripped.startswith("module"):
                in_module_header = True
                parts = stripped.split("module")[1].strip().split("(", 1)
                module_name = parts[0].strip()
                if len(parts) > 1:
                    rest = parts[1].strip()
                    if rest.endswith(");"):
                        port_text = rest[:-2]
                        port_lines.append(port_text)
                        break
                    else:
                        port_lines.append(rest)
                continue

            if in_module_header:
                if stripped.endswith(");"):
                    port_lines.append(stripped[:-2])
                    break
                else:
                    port_lines.append(stripped)
    all_ports = []
    for line in port_lines:
        ports = line.split(",")
        for p in ports:
            port = p.strip()
            if port:
                all_ports.append(port)
    return module_name, all_ports


def write_spi_netlist(instances, output_file,cells,cells_names):
        out_lines=[]
        for inst in instances:
            if inst.cell_type in cells_names:
                cell_index = cells_names.index(inst.cell_type)
                model_name = cells[cell_index].model_name
                instance_name = inst.instance_name
                ordered_pins = cells[cell_index].pins
            else:
                     raise TypeError(f"unrecognized cell")
            pin_signals = []
            for pin in ordered_pins:
                if pin in inst.extract_pins():
                    pin_signals.append(inst.extract_pins()[pin])
                else:
                    found = False
                    for conn_pin in inst.extract_pins():
                        if conn_pin.lower() == pin.lower():
                            pin_signals.append(inst.extract_pins()[conn_pin])
                            found = True
                            break
                    if not found:
                        pin_signals.append("problem")
            line = "X{} {} {}\n".format(instance_name, ' '.join(pin_signals), model_name)
            out_lines.append(line)
        return out_lines





def clean_lines(infile,outfile=None):
    out = []
    with open(infile, 'r') as f:
        for line in f:
            line = line.replace('5v0', '5v0_').strip()     
            if ('\\' in line) and ('[' in line or ']' in line) :
                line = line.replace('\\', '').strip()     
                line = line.replace('[', '_').strip()   
                line = line.replace(']', '_').strip()
            if ('\\' in line) :
                line = line.replace('\\', '').strip() 
            if not line.endswith("\n"):
                line += "\n"    
            out.append(line)
    out_path = outfile
    with open(out_path, 'w') as f:
        f.writelines(out)

def convert_extraction(verilog_file, spi_std_cell_lib,out_file,enable_extraction,spef_file=None ):
    #clean the verilog, rename nets 
    renamed_instances_verilog = 'renamed_verilog.v'
    clean_lines(verilog_file,renamed_instances_verilog)
    instances_classes_spi = generate_cell_class(spi_std_cell_lib)
    cells_names =  [cell.model_name for cell in instances_classes_spi]
    cell_types_dict = {cell.model_name: cell for cell in instances_classes_spi}
    verilog_instances_raw = extract_instances(renamed_instances_verilog, cell_types_dict.keys())
    instances_list=[]
    for i in verilog_instances_raw:
        instances_list.append(i.instance_name)
    renaming = 0
    replacing = 0
    dico = {}
    if enable_extraction:
     out_lines = []
     with open(spef_file, 'r', encoding='utf-8', errors='replace') as f:
         for line in f:
             stripped = line     .strip()
             if stripped.startswith('*PORTS'):
                 renaming = 0
                 replacing = 1
                 out_lines.append(line)
             elif stripped.startswith('*NAME_MAP'):
                 renaming = 1
                 replacing = 0
             elif renaming == 1 and replacing == 0 and stripped.startswith('*'):
                 try:
                     a, b = line.split(None, 1)
                     a = a.split('*')[1]
                     if '$' in b:
                         b = b.replace('[', '_').strip()
                         b = b.replace(']', '_').strip()
                     b = b.replace('\\', '').strip()
                     dico[a] = b
                 except Exception:
                     pass
             elif replacing == 1:
                 new_line = line
                 for k, v in dico.items():
                     if f'*{k}:' in new_line or f'*{k} ' in new_line and ':' in new_line.split(f'*{k}', 1)[1].lstrip():
                         new_line = new_line.replace(f'*{k}', v)
                 out_lines.append(new_line)
             else:
                 out_lines.append(line)
     extracted_out_lines = []
     in_cap_or_res = False
     current_section = None
     c = 0
     r = 0
     for linew in out_lines:
        stripped = linew.strip()
        new_line = None  
        if stripped.startswith('*CAP'):
            in_cap_or_res = True
            current_section = "CAP"
            new_line = linew
        elif stripped.startswith('*RES'):
            in_cap_or_res = True
            current_section = "RES"
            new_line = linew
        elif stripped.startswith('*'):
            in_cap_or_res = False
            current_section = None
        elif in_cap_or_res and not stripped.startswith('*'):
            signal0w=''
            singal1w=''
            if stripped and stripped[0].isdigit():
                parts = linew.split()
                if current_section == "CAP":
                    label = f"C_{c}"
                    c += 1
                else:
                    label = f"R_{r}"
                    r += 1
                if len(parts) == 3:
                    rest_parts = parts[1:]
                    signal0, value = rest_parts
                    if ':'  in signal0: #replace
                            instance_spef,pin_spef = signal0.split(':')
                            correspondance_instance_cell=0
                            correspondance_pins=0
                            if instance_spef in instances_list:
                                i = instances_list.index(instance_spef)
                                instance_tmp = verilog_instances_raw[i]
                                for cl in instances_classes_spi:
                                 if cl.model_name == instance_tmp.cell_type:
                                    correspondance_instance_cell+=1
                                    if pin_spef in instance_tmp.extract_pins():
                                           correspondance_pins+=1
                                           signal0w= instance_tmp.extract_pins()[pin_spef]
                            else:
                                signal0w=f'{instance_spef}_{pin_spef}'
                                correspondance_pins=1
                                correspondance_instance_cell=1
                    else:
                      signal0w=f"{signal0}"
                      correspondance_pins=1
                      correspondance_instance_cell=1
                    if  (correspondance_instance_cell != 1 or correspondance_pins!= 1):
                      raise TypeError(f"PB in correspondance between instance/cell or pin of the instance{instance_spef}, {correspondance_instance_cell}:correspondance_instance_cell, {correspondance_pins}: correspondance_pins")
                    signal1w ="VSS"
                elif len(parts) == 4 :
                     signal0=parts[1]
                     signal1=parts[2]
                     value=parts[3]
                     if ':'  in signal0: #replace
                            instance_spef,pin_spef = signal0.split(':')
                            correspondance_instance_cell=0
                            correspondance_pins=0
                            if instance_spef in instances_list:
                                i = instances_list.index(instance_spef)
                                instance_tmp = verilog_instances_raw[i]
                                for cl in instances_classes_spi:
                                 if cl.model_name == instance_tmp.cell_type:
                                    correspondance_instance_cell+=1
                                    if pin_spef in instance_tmp.extract_pins():
                                           correspondance_pins+=1
                                           signal0w= instance_tmp.extract_pins()[pin_spef]
                            else:
                                signal0w=f'{instance_spef}_{pin_spef}'
                                correspondance_pins=1
                                correspondance_instance_cell=1
                     else:
                      signal0w=f"{signal0}"
                      correspondance_pins=1
                      correspondance_instance_cell=1
                     if  (correspondance_instance_cell != 1 or correspondance_pins!= 1):
                         raise TypeError(f"PB in correspondance between instance/cell or pin of the instance{instance_spef}, {correspondance_instance_cell}:correspondance_instance_cell, {correspondance_pins}: correspondance_pins")
                     if ':'  in signal1: #replace
                            instance_spef,pin_spef = signal1.split(':')
                            correspondance_instance_cell=0
                            correspondance_pins=0
                            if instance_spef in instances_list:
                                i = instances_list.index(instance_spef)
                                instance_tmp = verilog_instances_raw[i]
                                for cl in instances_classes_spi:
                                 if cl.model_name == instance_tmp.cell_type:
                                    correspondance_instance_cell+=1
                                    if pin_spef in instance_tmp.extract_pins():
                                           correspondance_pins+=1
                                           signal1w= instance_tmp.extract_pins()[pin_spef]
                            else:
                                signal1w=f'{instance_spef}_{pin_spef}'
                                correspondance_pins=1
                                correspondance_instance_cell=1
                     else:
                      signal1w=f"{signal1}"
                      correspondance_pins=1
                      correspondance_instance_cell=1
                     if  (correspondance_instance_cell != 1 or correspondance_pins!= 1):
                      raise TypeError(f"PB in correspondance between instance/cell or pin of the instance{instance_spef}, {correspondance_instance_cell}:correspondance_instance_cell, {correspondance_pins}: correspondance_pins")
                rest = f"{signal0w} {signal1w} {value}"
                new_line = f"{label} {rest}\n" 
            else:
                new_line = linew
        if new_line is not None:
            extracted_out_lines.append(new_line)
    with open(out_file, 'w', encoding='utf-8') as fo:
        top_name, top_ports = get_top_module_info(verilog_file)
        fo.write(" \n.SUBCKT {} {}\n".format(top_name, ' '.join(top_ports)))
        fo.writelines(write_spi_netlist(verilog_instances_raw, out_file,instances_classes_spi,cells_names))
        if enable_extraction:
            fo.writelines(extracted_out_lines)
        fo.write(".ENDS {}\n".format(top_name))


def main():
 args = get_args() 
 spi_std_cell_lib= args.lib
 module =args.module
 verilog_file=f'{module}.v'
 if args.extracted:
    enable_extraction = True 
    spef_file=args.spef
    generated_spi_file= f'{module}_extracted.spi'
    convert_extraction(verilog_file,spi_std_cell_lib, generated_spi_file,enable_extraction,spef_file)    
 else:
    enable_extraction = False 
    generated_spi_file= f'{module}.spi'
    convert_extraction(verilog_file,spi_std_cell_lib, generated_spi_file,enable_extraction)    

if __name__ == "__main__":
    main()
